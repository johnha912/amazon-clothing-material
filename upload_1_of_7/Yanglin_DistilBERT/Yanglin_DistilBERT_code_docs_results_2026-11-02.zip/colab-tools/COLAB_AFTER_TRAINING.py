# %% Cell 1 — show the saved results and real errors
from pathlib import Path
import json
import pandas as pd
from IPython.display import display

root = Path("/content/amazon-clothing-material")
results = root / "results"
run = json.loads((results / "material_bert_run.json").read_text())
scores = pd.read_csv(results / "material_bert.csv")
comparison = pd.read_csv(results / "material_comparison.csv")
per_class = pd.read_csv(results / "material_bert_per_class.csv", index_col=0)
errors = pd.read_csv(results / "material_bert_errors.csv").fillna("")
predictions = pd.read_csv(results / "material_bert_predictions.csv")
assert len(predictions) == int(scores.iloc[0]["n_test"])

display(comparison[["model", "macro_f1", "accuracy", "n_train", "n_test"]])
print("GPU:", run["gpu"], "| Elapsed seconds:", run["elapsed_seconds"])
print("Selected epochs:", run["best_epoch"], "| Seed:", run["seed"])
print("Data:", run["data_version"])
print("Command:", run["command"])
print("Comparison status:", comparison["comparison_verification"].iloc[0])
display(per_class)
display(errors[["parent_asin", "title", "material", "predicted", "text"]].head(5))


# %% Cell 2 — view the confusion matrix
import plotly.express as px

matrix = pd.read_csv(results / "material_bert_confusion.csv", index_col=0)
fig = px.imshow(
    matrix, text_auto=True,
    labels={"x": "Predicted material", "y": "True material", "color": "Count"},
    title="DistilBERT — test confusion matrix",
)
fig.show(renderer="colab")


# %% Cell 3 — write the required model note and complete the prompt log
def md_table(frame):
    def clean(value):
        return str(value).replace("|", "\\|").replace("\n", " ").replace("\r", " ")
    lines = ["| " + " | ".join(map(clean, frame.columns)) + " |",
             "| " + " | ".join(["---"] * len(frame.columns)) + " |"]
    lines += ["| " + " | ".join(map(clean, row)) + " |"
              for row in frame.itertuples(index=False, name=None)]
    return "\n".join(lines)

metric_table = md_table(comparison[["model", "macro_f1", "accuracy"]].round(4))
pairs = (
    errors
    .groupby(["material", "predicted"])
    .size()
    .sort_values(ascending=False)
    .head(5)
    .rename("count")
    .reset_index()
)
examples = (
    errors
    .loc[:, ["parent_asin", "material", "predicted", "text"]]
    .head(5)
)
class_table = (
    per_class
    .loc[matrix.index, ["precision", "recall", "f1-score", "support"]]
    .round(4)
    .rename_axis("material")
    .reset_index()
)
note = f"""# DistilBERT material classification

Owner: Yanglin Hu. This is a completed pilot run, not a final-report acceptance.

## Method and rationale

The model fine-tunes pretrained DistilBERT on the shared composition-free listing text. Its contextual token representations can capture phrases and word relationships beyond TF-IDF word counts. A classification head transforms the first-token representation into logits z, with p = softmax(z). The unweighted training loss is cross-entropy, L = -mean(log(p_correct)). Macro-F1 is the mean of the per-class F1 scores, giving rare and common materials equal importance.

Labels and cleaned text come from the shared loader, without reimplementing the composition parser. Only labeled classes with the same minimum support as the TF-IDF baseline are retained. Neither average_rating nor rating_number is supplied to the tokenizer. Percentage composition segments are removed because they generated the labels.

## Experimental setup and provenance

The data version is {run['data_version']}. The seed is {run['seed']}; the frozen population contains {run['n_train']} training rows, {run['n_test']} test rows and {run['n_classes']} classes. Epoch selection used {run['n_selection_fit']} fit rows and {run['n_validation']} validation rows drawn only from the training split. Validation selected {run['best_epoch']} epoch(s). A fresh pretrained model was refit on every training row for that many epochs before one final test prediction.

The exact command was `{run['command']}`. The GPU was {run['gpu']}; recorded elapsed time was {run['elapsed_seconds']} seconds. Pretrained revision: `{run['model_revision']}`. Task fingerprint: `{run['task_fingerprint']}`. Full hyperparameters, package versions, source hash, test-ID hash and runtime provenance are in `results/material_bert_run.json`; the exact split manifest and validation history are in `models/material_bert/`.

## Pilot results

{metric_table}

Comparison verification is `{comparison['comparison_verification'].iloc[0]}`. The legacy TF-IDF CSV does not prove identical listing identities/text/labels through a fingerprint. Nguyen must confirm that all three runs used the same frozen population before the table is treated as final. The evaluator for this run was `{run['evaluator']}`. Required shared-evaluator verification and independent audit remain pending before report acceptance.

## Error analysis

The per-class table shows which materials contribute to the macro-F1 result. Accuracy gives more influence to frequent labels, whereas macro-F1 gives every class equal weight; therefore accuracy alone is insufficient for this imbalanced task.

{md_table(class_table)}

The most frequent true-to-predicted error pairs in this saved test prediction are:

{md_table(pairs)}

Five actual error examples, or all errors if fewer than five exist, are:

{md_table(examples)}

The full confusion matrix is `results/material_bert_confusion.csv` and its interactive view is `results/material_bert_confusion.html`. The complete saved test predictions and short error excerpts are available in the corresponding prediction/error CSVs. Review these examples before assigning a specific cause to an individual mistake.

Possible contributors include imbalanced class support, listings mentioning multiple fibers, and truncation of late evidence. This run uses unweighted cross-entropy, while the TF-IDF classifiers use balanced class weights. These are explanations to investigate using training/validation data, not causes established by this single experiment. This pilot does not establish that a contextual model will outperform the simpler baselines. Preserve the test result; future configuration selection must remain on training/validation data.

## Scope and transfer

The shared scope still includes shoes; Yanglin and Nguyen have not jointly resolved the upper-versus-sole label ambiguity. Inspect training examples to decide that scope with the pipeline owner, freeze any changed sample, and rerun every model consistently. Do not change scope in response to test errors.

The reusable parts are the shared label rule, composition-leakage guard, validation-only epoch selection, frozen test evaluation and saved provenance. Applying this workflow to another category requires checking its material vocabulary, label coverage and component ambiguity again.
"""
note_path = root / "docs/model-notes/material_bert.md"
note_path.parent.mkdir(parents=True, exist_ok=True)
note_path.write_text(note, encoding="utf-8")

prompt_summaries = [
    ("Implement my DistilBERT material-model contribution, save test macro-F1, and prepare comparison and shoe-scope coordination with Nguyen.", "`analysis/material_bert.py`"),
    ("Prepare a Colab-ready script because there is no existing project notebook.", "DistilBERT Colab workflow"),
    ("Explain the Colab missing-file error after cloning the repository and enabling the T4 GPU.", "Colab script upload troubleshooting"),
    ("Diagnose the Colab Trainer import failure caused by the torchvision nms operator and correct the text-model setup instructions.", "Colab dependency troubleshooting"),
    ("Fix the Colab pretrained-model revision check after successful weight downloads and explain how to retry training.", "Model revision tracking and Colab retry"),
    ("Read the completed Colab run and provide the remaining paste-ready cells to inspect, document and save the results.", "Post-training Colab cells and model note"),
]
log_path = root / "ai-prompts.md"
existing = log_path.read_text(encoding="utf-8")
rows = [f"| 2026-11-02 | Yanglin Hu | Codex | {summary} | {task} |"
        for summary, task in prompt_summaries]
with log_path.open("a", encoding="utf-8") as stream:
    for row in rows:
        if row not in existing:
            stream.write("\n" + row)
    stream.write("\n")
print("Saved:", note_path)
print("Updated:", log_path)


# %% Cell 4 — download a complete backup, including the trained model
from zipfile import ZipFile, ZIP_DEFLATED
from google.colab import files

model_dir = root / "models/material_bert"
assert (model_dir / "final/config.json").exists(), "Saved model is missing."
archive_path = Path("/content/yanglin-material-bert-complete.zip")
members = [root / "analysis/material_bert.py", note_path, log_path,
           results / "material_comparison.csv", results / "material_tfidf.csv"]
members += sorted(results.glob("material_bert*"))
members += sorted(path for path in model_dir.rglob("*") if path.is_file())
with ZipFile(archive_path, "w", ZIP_DEFLATED, compresslevel=1) as archive:
    for path in members:
        if path.is_file():
            archive.write(path, path.relative_to(root))
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None, "Archive verification failed."
print(f"Backup size: {archive_path.stat().st_size() / 1024**2:.1f} MB")
files.download(str(archive_path))
